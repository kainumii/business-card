import BusinessCard from "./components/BusinessCard";

function App() {
  return <BusinessCard />;
}

export default App;
